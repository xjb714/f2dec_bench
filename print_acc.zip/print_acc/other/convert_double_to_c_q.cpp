#include <iostream>
#include <stdint.h>
using namespace std;
typedef uint64_t u64;
int main(){
    double num;
    //printf("Enter a double number: ");
    //cin>>num;
    num = 1.3076622631878654e65;
    u64 bits = *(u64*)&num;
    u64 c = bits & ((1ull<<52) - 1);
    int q = ((bits >> 52) & 0x7FF) - 1075;
    if(q==-1075)q=-1074;
    else c |= (1ull<<52);
    printf("c: %llu\n", c);
    printf("q: %d\n", q);
}