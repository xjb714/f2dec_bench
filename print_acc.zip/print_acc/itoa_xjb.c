#if 1
#include <stdint.h>
typedef __uint128_t u128;
typedef uint64_t u64;
typedef uint32_t u32;
typedef int32_t i32;
#define C2(x, y)                                                          \
    x, y, '0', 0, x, y, '1', 0, x, y, '2', 0, x, y, '3', 0, x, y, '4', 0, \
    x, y, '5', 0, x, y, '6', 0, x, y, '7', 0, x, y, '8', 0, x, y, '9', 0
#define C1(x)                                                   \
    C2(x, '0'), C2(x, '1'), C2(x, '2'), C2(x, '3'), C2(x, '4'), \
    C2(x, '5'), C2(x, '6'), C2(x, '7'), C2(x, '8'), C2(x, '9')
/* Lookup table for 3 digits (4000 bytes):     */
/* { "000"\0  "001"\0  "002"\0  ...  "999"\0 } */
static const char digit1000_ptr[] = {
    C1('0'), C1('1'), C1('2'), C1('3'), C1('4'),
    C1('5'), C1('6'), C1('7'), C1('8'), C1('9')};

char *itoa_u32_xjb(uint32_t val, char *buf)
{
    const u32 *digit1000 = (u32 *)digit1000_ptr;
    if (val < 1000u) /* 1-3 digits: aaa ; 0 <= a <= 999 */
    {
        u32 lz = (val < 10) + (val < 100);
        *(u32 *)buf = ((u32 *)(digit1000_ptr + lz))[val]; // write 1-3 byte
        return buf + 3 - lz;
    }
    if (val < 1000 * 1000u) /* 4-6 digits: aaa bbb ; 1 <= a <= 999 */
    {
        u32 lz = (val < (10 * 1000u)) + (val < (100 * 1000u));
        u32 aaa = (val * (u64)1073742) >> 30; // div 1000
        u32 bbb = val - aaa * 1000;
        *(u32 *)buf = ((u32 *)(digit1000_ptr + lz))[aaa];
        buf -= lz;
        *(u32 *)(buf + 3) = digit1000[bbb];
        return buf + 6;
    }
    if (val < 1000 * 1000 * 1000u) /* 7-9 digits: aaa bbb ccc ; 1 <= a <= 999 */
    {
        u32 aaa = (val * (u64)1125899907) >> 50;                             // div 1e6
        u32 lz = (val < (10 * 1000 * 1000u)) + (val < (100 * 1000 * 1000u)); // 1e7,1e8
        *(u32 *)buf = ((u32 *)(digit1000_ptr + lz))[aaa];
        buf -= lz;
        u32 bbbccc = val - aaa * (1000 * 1000u);
        u32 bbb = (bbbccc * (u64)1073742) >> 30;
        u32 ccc = bbbccc - bbb * 1000u;
        *(u32 *)(buf + 3) = digit1000[bbb];
        *(u32 *)(buf + 6) = digit1000[ccc];
        return buf + 9;
    }
    /* 10 digits: aaa bbb ccc d ; 100 <= aaa <= 429 */ /* U32_MAX = 4294967295 */
    u32 aaabbb = (val * (u64)3518437209) >> 45; // div 10000
    u32 cccd = val - aaabbb * 10000;
    u32 aaa = (aaabbb * (u64)1073742) >> 30; // div 1000
    u32 bbb = aaabbb - aaa * 1000;
    u32 ccc = (cccd * 13108) >> 17; //  div 10
    u32 d = cccd - ccc * 10;
    *(u32 *)buf = digit1000[aaa];
    *(u32 *)(buf + 3) = digit1000[bbb];
    *(u32 *)(buf + 6) = digit1000[ccc];
    *(buf + 9) = d + '0';
    //*(unsigned short*)(buf + 9) = d + ('0' + ('\n' * 256));
    return buf + 10;
}

char *itoa_i32_xjb(int32_t val, char *buf)
{
    u32 sign = val < 0;
    *buf = '-';
    return itoa_u32_xjb( (sign ? -val : val), buf + sign);
}

char *itoa_u64_xjb(uint64_t val, char *buf)
{
    const u64 E3 = 1000;
    const u64 E6 = E3 * E3;
    const u64 E9 = E6 * E3;
    const u64 E12 = E6 * E6;
    const u32 *digit1000 = (u32 *)digit1000_ptr;
    if (val < E3) /* 1-3 digits: aaa */
    {
        u32 lz = (val < 10) + (val < 100);
        *(u32 *)buf = ((u32 *)(digit1000_ptr + lz))[val];
        return buf + 3 - lz;
    }
    if (val < E6) /* 4-6 digits: aaabbb */
    {
        u32 lz = (val < (E3 * 10)) + (val < (E3 * 100));
        uint32_t aaa = (val * (u64)4294968) >> 32; /* (val / 1000) */
        uint32_t bbb = val - aaa * 1000;
        *(u32 *)buf = ((u32 *)(digit1000_ptr + lz))[aaa];
        buf -= lz;
        *(u32 *)(buf + 3) = digit1000[bbb];
        return buf + 6;
    }
    if (val < E9) /* 7-9 digits: aaabbbccc */
    {
        u32 lz = (val < (E6 * 10)) + (val < (E6 * 100)); // 1e7,1e8
        u32 aaa = (val * (u64)1125899907) >> 50;         // div 1e6
        u32 bbbccc = val - aaa * (1000 * 1000u);
        u32 bbb = (bbbccc * (u64)1073742) >> 30;
        u32 ccc = bbbccc - bbb * 1000u;
        *(u32 *)buf = ((u32 *)(digit1000_ptr + lz))[aaa];
        buf -= lz;
        *(u32 *)(buf + 3) = digit1000[bbb];
        *(u32 *)(buf + 6) = digit1000[ccc];
        return buf + 9;
    }
    if (val < E12) /* 10-12 digits: aaabbbcccddd */
    {
        u32 lz = (val < (E9 * 10)) + (val < (E9 * 100));
        u32 aaabbb = (val * (u128)18446744073710) >> 64;
        u32 cccddd = val - aaabbb * E6;
        u32 aaa = (aaabbb * (u64)4294968) >> 32;
        u32 bbb = aaabbb - aaa * 1000;
        u32 ccc = (cccddd * (u64)4294968) >> 32;
        u32 ddd = cccddd - ccc * 1000;
        *(u32 *)buf = ((u32 *)(digit1000_ptr + lz))[aaa];
        buf -= lz;
        *(u32 *)(buf + 3) = digit1000[bbb];
        *(u32 *)(buf + 6) = digit1000[ccc];
        *(u32 *)(buf + 9) = digit1000[ddd];
        return buf + 12;
    }
    if (val < E12 * E3) /* 13-15 digits: aaabbbcccdddeee */
    {
        u32 lz = (val < E12 * 10) + (val < E12 * 100);
        u64 aaabbb = val / E9;
        u64 cccdddeee = val - aaabbb * E9;
        u32 aaa = (aaabbb * (u64)4294968) >> 32;
        u32 bbb = aaabbb - aaa * 1000;
        u32 ccc = (cccdddeee * (u64)1125899907) >> 50;
        u32 dddeee = cccdddeee - ccc * E6;
        u32 ddd = (dddeee * (u64)4294968) >> 32;
        u32 eee = dddeee - ddd * 1000;
        *(u32 *)buf = ((u32 *)(digit1000_ptr + lz))[aaa];
        buf -= lz;
        *(u32 *)(buf + 3) = digit1000[bbb];
        *(u32 *)(buf + 6) = digit1000[ccc];
        *(u32 *)(buf + 9) = digit1000[ddd];
        *(u32 *)(buf + 12) = digit1000[eee];
        return buf + 15;
    }
    if (val < E12 * E6) /* 16-18 digits: aaabbbcccdddeeefff */
    {
        u32 lz = (val < E12 * E3 * 10) + (val < E12 * E3 * 100);
        u64 aaabbb = val / E12;
        u64 cccdddeeefff = val - aaabbb * E12;
        u64 cccddd = ((u128)cccdddeeefff * 18446744073710) >> 64;
        u64 eeefff = cccdddeeefff - cccddd * E6;
        u32 aaa = (aaabbb * (u64)4294968) >> 32;
        u32 bbb = aaabbb - aaa * 1000;
        u32 ccc = (cccddd * (u64)4294968) >> 32;
        u32 ddd = cccddd - ccc * 1000;
        u32 eee = (eeefff * (u64)4294968) >> 32;
        u32 fff = eeefff - eee * 1000;
        *(u32 *)buf = ((u32 *)(digit1000_ptr + lz))[aaa];
        buf -= lz;
        *(u32 *)(buf + 3) = digit1000[bbb];
        *(u32 *)(buf + 6) = digit1000[ccc];
        *(u32 *)(buf + 9) = digit1000[ddd];
        *(u32 *)(buf + 12) = digit1000[eee];
        *(u32 *)(buf + 15) = digit1000[fff];
        return buf + 18;
    }
    /* 19-20 digits: 2 + 18 = hgh + aaabbbcccdddeeefff ; 1 <= hgh <= 18 */
    {
        u32 lz = val < E12 * E6 * 10;
        u64 tmp = val / E9;
        u32 low = (val - tmp * E9); // 9 digit
        u32 hgh = (tmp / E9);       // 1-2 digit
        u32 mid = (tmp - hgh * E9); // 9 digit
        *(u32 *)buf = ((u32 *)(digit1000_ptr + 1 + lz))[hgh];
        buf += 2 - lz;
        u32 aaa = (mid * (u64)1125899907) >> 50;
        *(u32 *)buf = digit1000[aaa];
        u32 bbbccc = mid - aaa * (1000 * 1000u);
        u32 bbb = (bbbccc * (u64)1073742) >> 30;
        u32 ccc = bbbccc - bbb * 1000u;
        *(u32 *)(buf + 3) = digit1000[bbb];
        *(u32 *)(buf + 6) = digit1000[ccc];
        u32 ddd = (low * (u64)1125899907) >> 50;
        *(u32 *)(buf + 9) = digit1000[ddd];
        u32 eeefff = low - ddd * (1000 * 1000u);
        u32 eee = (eeefff * (u64)1073742) >> 30;
        u32 fff = eeefff - eee * 1000u;
        *(u32 *)(buf + 12) = digit1000[eee];
        *(u32 *)(buf + 15) = digit1000[fff];
        return buf + 18;
    }
}

char *itoa_i64_xjb(int64_t val, char *buf)
{
    u32 sign = val < 0;
    *buf = '-';
    return itoa_u64_xjb( (sign ? -val : val), buf + sign);
}

/* benckmark config */
int itoa_xjb_available_32 = 1;
int itoa_xjb_available_64 = 1;

#else

// /*
//  * Integer to ascii conversion (ANSI C)
//  *
//  * Description
//  *     The itoa function converts an integer value to a character string in
//  *     decimal and stores the result in the buffer. If value is negative, the
//  *     resulting string is preceded with a minus sign (-).
//  *
//  * Parameters
//  *     val: Value to be converted.
//  *     buf: Buffer that holds the result of the conversion.
//  *
//  * Return Value
//  *     A pointer to the end of resulting string.
//  *
//  * Notice
//  *     The resulting string is not null-terminated.
//  *     The buffer should be large enough to hold any possible result:
//  *         uint32_t: max 11 bytes  , the last write byte is not use
//  *         uint64_t: max 21 bytes  , the last write byte is not use
//  *         int32_t : max 12 bytes  , the last write byte is not use
//  *         int64_t : max 21 bytes  , the last write byte is not use
//  *
//  * Copyright (c) 2025.6.18 xjb <1302035400@qq.com> github.com/xjb714
//  * Released under the MIT license (MIT).
//  */

#include <stdint.h>
#include <stddef.h>
#include <string.h>

#if defined(__has_attribute)
#define yy_attribute(x) __has_attribute(x)
#else
#define yy_attribute(x) 0
#endif

#if !defined(force_inline)
#if yy_attribute(always_inline) || (defined(__GNUC__) && __GNUC__ >= 4)
#define force_inline __inline__ __attribute__((always_inline))
#elif defined(__clang__) || defined(__GNUC__)
#define force_inline __inline__
#elif defined(_MSC_VER) && _MSC_VER >= 1200
#define force_inline __forceinline
#elif defined(_MSC_VER)
#define force_inline __inline
#elif defined(__cplusplus) || (defined(__STDC__) && __STDC__ && \
                               defined(__STDC_VERSION__) && __STDC_VERSION__ >= 199901L)
#define force_inline inline
#else
#define force_inline
#endif
#endif

typedef uint64_t u64;
typedef uint32_t u32;
typedef __uint128_t u128;
const u64 E6 = 1000 * 1000;

// 4800 byte = 4.6875 KB
static unsigned int digit1000_sig[1000] = {0x3303030, 0x3313030, 0x3323030, 0x3333030, 0x3343030, 0x3353030, 0x3363030, 0x3373030, 0x3383030, 0x3393030, 0x3303130, 0x3313130, 0x3323130, 0x3333130, 0x3343130, 0x3353130, 0x3363130, 0x3373130, 0x3383130, 0x3393130, 0x3303230, 0x3313230, 0x3323230, 0x3333230, 0x3343230, 0x3353230, 0x3363230, 0x3373230, 0x3383230, 0x3393230, 0x3303330, 0x3313330, 0x3323330, 0x3333330, 0x3343330, 0x3353330, 0x3363330, 0x3373330, 0x3383330, 0x3393330, 0x3303430, 0x3313430, 0x3323430, 0x3333430, 0x3343430, 0x3353430, 0x3363430, 0x3373430, 0x3383430, 0x3393430, 0x3303530, 0x3313530, 0x3323530, 0x3333530, 0x3343530, 0x3353530, 0x3363530, 0x3373530, 0x3383530, 0x3393530, 0x3303630, 0x3313630, 0x3323630, 0x3333630, 0x3343630, 0x3353630, 0x3363630, 0x3373630, 0x3383630, 0x3393630, 0x3303730, 0x3313730, 0x3323730, 0x3333730, 0x3343730, 0x3353730, 0x3363730, 0x3373730, 0x3383730, 0x3393730, 0x3303830, 0x3313830, 0x3323830, 0x3333830, 0x3343830, 0x3353830, 0x3363830, 0x3373830, 0x3383830, 0x3393830, 0x3303930, 0x3313930, 0x3323930, 0x3333930, 0x3343930, 0x3353930, 0x3363930, 0x3373930, 0x3383930, 0x3393930, 0x3303031, 0x3313031, 0x3323031, 0x3333031, 0x3343031, 0x3353031, 0x3363031, 0x3373031, 0x3383031, 0x3393031, 0x3303131, 0x3313131, 0x3323131, 0x3333131, 0x3343131, 0x3353131, 0x3363131, 0x3373131, 0x3383131, 0x3393131, 0x3303231, 0x3313231, 0x3323231, 0x3333231, 0x3343231, 0x3353231, 0x3363231, 0x3373231, 0x3383231, 0x3393231, 0x3303331, 0x3313331, 0x3323331, 0x3333331, 0x3343331, 0x3353331, 0x3363331, 0x3373331, 0x3383331, 0x3393331, 0x3303431, 0x3313431, 0x3323431, 0x3333431, 0x3343431, 0x3353431, 0x3363431, 0x3373431, 0x3383431, 0x3393431, 0x3303531, 0x3313531, 0x3323531, 0x3333531, 0x3343531, 0x3353531, 0x3363531, 0x3373531, 0x3383531, 0x3393531, 0x3303631, 0x3313631, 0x3323631, 0x3333631, 0x3343631, 0x3353631, 0x3363631, 0x3373631, 0x3383631, 0x3393631, 0x3303731, 0x3313731, 0x3323731, 0x3333731, 0x3343731, 0x3353731, 0x3363731, 0x3373731, 0x3383731, 0x3393731, 0x3303831, 0x3313831, 0x3323831, 0x3333831, 0x3343831, 0x3353831, 0x3363831, 0x3373831, 0x3383831, 0x3393831, 0x3303931, 0x3313931, 0x3323931, 0x3333931, 0x3343931, 0x3353931, 0x3363931, 0x3373931, 0x3383931, 0x3393931, 0x3303032, 0x3313032, 0x3323032, 0x3333032, 0x3343032, 0x3353032, 0x3363032, 0x3373032, 0x3383032, 0x3393032, 0x3303132, 0x3313132, 0x3323132, 0x3333132, 0x3343132, 0x3353132, 0x3363132, 0x3373132, 0x3383132, 0x3393132, 0x3303232, 0x3313232, 0x3323232, 0x3333232, 0x3343232, 0x3353232, 0x3363232, 0x3373232, 0x3383232, 0x3393232, 0x3303332, 0x3313332, 0x3323332, 0x3333332, 0x3343332, 0x3353332, 0x3363332, 0x3373332, 0x3383332, 0x3393332, 0x3303432, 0x3313432, 0x3323432, 0x3333432, 0x3343432, 0x3353432, 0x3363432, 0x3373432, 0x3383432, 0x3393432, 0x3303532, 0x3313532, 0x3323532, 0x3333532, 0x3343532, 0x3353532, 0x3363532, 0x3373532, 0x3383532, 0x3393532, 0x3303632, 0x3313632, 0x3323632, 0x3333632, 0x3343632, 0x3353632, 0x3363632, 0x3373632, 0x3383632, 0x3393632, 0x3303732, 0x3313732, 0x3323732, 0x3333732, 0x3343732, 0x3353732, 0x3363732, 0x3373732, 0x3383732, 0x3393732, 0x3303832, 0x3313832, 0x3323832, 0x3333832, 0x3343832, 0x3353832, 0x3363832, 0x3373832, 0x3383832, 0x3393832, 0x3303932, 0x3313932, 0x3323932, 0x3333932, 0x3343932, 0x3353932, 0x3363932, 0x3373932, 0x3383932, 0x3393932, 0x3303033, 0x3313033, 0x3323033, 0x3333033, 0x3343033, 0x3353033, 0x3363033, 0x3373033, 0x3383033, 0x3393033, 0x3303133, 0x3313133, 0x3323133, 0x3333133, 0x3343133, 0x3353133, 0x3363133, 0x3373133, 0x3383133, 0x3393133, 0x3303233, 0x3313233, 0x3323233, 0x3333233, 0x3343233, 0x3353233, 0x3363233, 0x3373233, 0x3383233, 0x3393233, 0x3303333, 0x3313333, 0x3323333, 0x3333333, 0x3343333, 0x3353333, 0x3363333, 0x3373333, 0x3383333, 0x3393333, 0x3303433, 0x3313433, 0x3323433, 0x3333433, 0x3343433, 0x3353433, 0x3363433, 0x3373433, 0x3383433, 0x3393433, 0x3303533, 0x3313533, 0x3323533, 0x3333533, 0x3343533, 0x3353533, 0x3363533, 0x3373533, 0x3383533, 0x3393533, 0x3303633, 0x3313633, 0x3323633, 0x3333633, 0x3343633, 0x3353633, 0x3363633, 0x3373633, 0x3383633, 0x3393633, 0x3303733, 0x3313733, 0x3323733, 0x3333733, 0x3343733, 0x3353733, 0x3363733, 0x3373733, 0x3383733, 0x3393733, 0x3303833, 0x3313833, 0x3323833, 0x3333833, 0x3343833, 0x3353833, 0x3363833, 0x3373833, 0x3383833, 0x3393833, 0x3303933, 0x3313933, 0x3323933, 0x3333933, 0x3343933, 0x3353933, 0x3363933, 0x3373933, 0x3383933, 0x3393933, 0x3303034, 0x3313034, 0x3323034, 0x3333034, 0x3343034, 0x3353034, 0x3363034, 0x3373034, 0x3383034, 0x3393034, 0x3303134, 0x3313134, 0x3323134, 0x3333134, 0x3343134, 0x3353134, 0x3363134, 0x3373134, 0x3383134, 0x3393134, 0x3303234, 0x3313234, 0x3323234, 0x3333234, 0x3343234, 0x3353234, 0x3363234, 0x3373234, 0x3383234, 0x3393234, 0x3303334, 0x3313334, 0x3323334, 0x3333334, 0x3343334, 0x3353334, 0x3363334, 0x3373334, 0x3383334, 0x3393334, 0x3303434, 0x3313434, 0x3323434, 0x3333434, 0x3343434, 0x3353434, 0x3363434, 0x3373434, 0x3383434, 0x3393434, 0x3303534, 0x3313534, 0x3323534, 0x3333534, 0x3343534, 0x3353534, 0x3363534, 0x3373534, 0x3383534, 0x3393534, 0x3303634, 0x3313634, 0x3323634, 0x3333634, 0x3343634, 0x3353634, 0x3363634, 0x3373634, 0x3383634, 0x3393634, 0x3303734, 0x3313734, 0x3323734, 0x3333734, 0x3343734, 0x3353734, 0x3363734, 0x3373734, 0x3383734, 0x3393734, 0x3303834, 0x3313834, 0x3323834, 0x3333834, 0x3343834, 0x3353834, 0x3363834, 0x3373834, 0x3383834, 0x3393834, 0x3303934, 0x3313934, 0x3323934, 0x3333934, 0x3343934, 0x3353934, 0x3363934, 0x3373934, 0x3383934, 0x3393934, 0x3303035, 0x3313035, 0x3323035, 0x3333035, 0x3343035, 0x3353035, 0x3363035, 0x3373035, 0x3383035, 0x3393035, 0x3303135, 0x3313135, 0x3323135, 0x3333135, 0x3343135, 0x3353135, 0x3363135, 0x3373135, 0x3383135, 0x3393135, 0x3303235, 0x3313235, 0x3323235, 0x3333235, 0x3343235, 0x3353235, 0x3363235, 0x3373235, 0x3383235, 0x3393235, 0x3303335, 0x3313335, 0x3323335, 0x3333335, 0x3343335, 0x3353335, 0x3363335, 0x3373335, 0x3383335, 0x3393335, 0x3303435, 0x3313435, 0x3323435, 0x3333435, 0x3343435, 0x3353435, 0x3363435, 0x3373435, 0x3383435, 0x3393435, 0x3303535, 0x3313535, 0x3323535, 0x3333535, 0x3343535, 0x3353535, 0x3363535, 0x3373535, 0x3383535, 0x3393535, 0x3303635, 0x3313635, 0x3323635, 0x3333635, 0x3343635, 0x3353635, 0x3363635, 0x3373635, 0x3383635, 0x3393635, 0x3303735, 0x3313735, 0x3323735, 0x3333735, 0x3343735, 0x3353735, 0x3363735, 0x3373735, 0x3383735, 0x3393735, 0x3303835, 0x3313835, 0x3323835, 0x3333835, 0x3343835, 0x3353835, 0x3363835, 0x3373835, 0x3383835, 0x3393835, 0x3303935, 0x3313935, 0x3323935, 0x3333935, 0x3343935, 0x3353935, 0x3363935, 0x3373935, 0x3383935, 0x3393935, 0x3303036, 0x3313036, 0x3323036, 0x3333036, 0x3343036, 0x3353036, 0x3363036, 0x3373036, 0x3383036, 0x3393036, 0x3303136, 0x3313136, 0x3323136, 0x3333136, 0x3343136, 0x3353136, 0x3363136, 0x3373136, 0x3383136, 0x3393136, 0x3303236, 0x3313236, 0x3323236, 0x3333236, 0x3343236, 0x3353236, 0x3363236, 0x3373236, 0x3383236, 0x3393236, 0x3303336, 0x3313336, 0x3323336, 0x3333336, 0x3343336, 0x3353336, 0x3363336, 0x3373336, 0x3383336, 0x3393336, 0x3303436, 0x3313436, 0x3323436, 0x3333436, 0x3343436, 0x3353436, 0x3363436, 0x3373436, 0x3383436, 0x3393436, 0x3303536, 0x3313536, 0x3323536, 0x3333536, 0x3343536, 0x3353536, 0x3363536, 0x3373536, 0x3383536, 0x3393536, 0x3303636, 0x3313636, 0x3323636, 0x3333636, 0x3343636, 0x3353636, 0x3363636, 0x3373636, 0x3383636, 0x3393636, 0x3303736, 0x3313736, 0x3323736, 0x3333736, 0x3343736, 0x3353736, 0x3363736, 0x3373736, 0x3383736, 0x3393736, 0x3303836, 0x3313836, 0x3323836, 0x3333836, 0x3343836, 0x3353836, 0x3363836, 0x3373836, 0x3383836, 0x3393836, 0x3303936, 0x3313936, 0x3323936, 0x3333936, 0x3343936, 0x3353936, 0x3363936, 0x3373936, 0x3383936, 0x3393936, 0x3303037, 0x3313037, 0x3323037, 0x3333037, 0x3343037, 0x3353037, 0x3363037, 0x3373037, 0x3383037, 0x3393037, 0x3303137, 0x3313137, 0x3323137, 0x3333137, 0x3343137, 0x3353137, 0x3363137, 0x3373137, 0x3383137, 0x3393137, 0x3303237, 0x3313237, 0x3323237, 0x3333237, 0x3343237, 0x3353237, 0x3363237, 0x3373237, 0x3383237, 0x3393237, 0x3303337, 0x3313337, 0x3323337, 0x3333337, 0x3343337, 0x3353337, 0x3363337, 0x3373337, 0x3383337, 0x3393337, 0x3303437, 0x3313437, 0x3323437, 0x3333437, 0x3343437, 0x3353437, 0x3363437, 0x3373437, 0x3383437, 0x3393437, 0x3303537, 0x3313537, 0x3323537, 0x3333537, 0x3343537, 0x3353537, 0x3363537, 0x3373537, 0x3383537, 0x3393537, 0x3303637, 0x3313637, 0x3323637, 0x3333637, 0x3343637, 0x3353637, 0x3363637, 0x3373637, 0x3383637, 0x3393637, 0x3303737, 0x3313737, 0x3323737, 0x3333737, 0x3343737, 0x3353737, 0x3363737, 0x3373737, 0x3383737, 0x3393737, 0x3303837, 0x3313837, 0x3323837, 0x3333837, 0x3343837, 0x3353837, 0x3363837, 0x3373837, 0x3383837, 0x3393837, 0x3303937, 0x3313937, 0x3323937, 0x3333937, 0x3343937, 0x3353937, 0x3363937, 0x3373937, 0x3383937, 0x3393937, 0x3303038, 0x3313038, 0x3323038, 0x3333038, 0x3343038, 0x3353038, 0x3363038, 0x3373038, 0x3383038, 0x3393038, 0x3303138, 0x3313138, 0x3323138, 0x3333138, 0x3343138, 0x3353138, 0x3363138, 0x3373138, 0x3383138, 0x3393138, 0x3303238, 0x3313238, 0x3323238, 0x3333238, 0x3343238, 0x3353238, 0x3363238, 0x3373238, 0x3383238, 0x3393238, 0x3303338, 0x3313338, 0x3323338, 0x3333338, 0x3343338, 0x3353338, 0x3363338, 0x3373338, 0x3383338, 0x3393338, 0x3303438, 0x3313438, 0x3323438, 0x3333438, 0x3343438, 0x3353438, 0x3363438, 0x3373438, 0x3383438, 0x3393438, 0x3303538, 0x3313538, 0x3323538, 0x3333538, 0x3343538, 0x3353538, 0x3363538, 0x3373538, 0x3383538, 0x3393538, 0x3303638, 0x3313638, 0x3323638, 0x3333638, 0x3343638, 0x3353638, 0x3363638, 0x3373638, 0x3383638, 0x3393638, 0x3303738, 0x3313738, 0x3323738, 0x3333738, 0x3343738, 0x3353738, 0x3363738, 0x3373738, 0x3383738, 0x3393738, 0x3303838, 0x3313838, 0x3323838, 0x3333838, 0x3343838, 0x3353838, 0x3363838, 0x3373838, 0x3383838, 0x3393838, 0x3303938, 0x3313938, 0x3323938, 0x3333938, 0x3343938, 0x3353938, 0x3363938, 0x3373938, 0x3383938, 0x3393938, 0x3303039, 0x3313039, 0x3323039, 0x3333039, 0x3343039, 0x3353039, 0x3363039, 0x3373039, 0x3383039, 0x3393039, 0x3303139, 0x3313139, 0x3323139, 0x3333139, 0x3343139, 0x3353139, 0x3363139, 0x3373139, 0x3383139, 0x3393139, 0x3303239, 0x3313239, 0x3323239, 0x3333239, 0x3343239, 0x3353239, 0x3363239, 0x3373239, 0x3383239, 0x3393239, 0x3303339, 0x3313339, 0x3323339, 0x3333339, 0x3343339, 0x3353339, 0x3363339, 0x3373339, 0x3383339, 0x3393339, 0x3303439, 0x3313439, 0x3323439, 0x3333439, 0x3343439, 0x3353439, 0x3363439, 0x3373439, 0x3383439, 0x3393439, 0x3303539, 0x3313539, 0x3323539, 0x3333539, 0x3343539, 0x3353539, 0x3363539, 0x3373539, 0x3383539, 0x3393539, 0x3303639, 0x3313639, 0x3323639, 0x3333639, 0x3343639, 0x3353639, 0x3363639, 0x3373639, 0x3383639, 0x3393639, 0x3303739, 0x3313739, 0x3323739, 0x3333739, 0x3343739, 0x3353739, 0x3363739, 0x3373739, 0x3383739, 0x3393739, 0x3303839, 0x3313839, 0x3323839, 0x3333839, 0x3343839, 0x3353839, 0x3363839, 0x3373839, 0x3383839, 0x3393839, 0x3303939, 0x3313939, 0x3323939, 0x3333939, 0x3343939, 0x3353939, 0x3363939, 0x3373939, 0x3383939, 0x3393939};
static unsigned int digit100_rlz_sig[100] = {0x1000030, 0x1000031, 0x1000032, 0x1000033, 0x1000034, 0x1000035, 0x1000036, 0x1000037, 0x1000038, 0x1000039, 0x2003031, 0x2003131, 0x2003231, 0x2003331, 0x2003431, 0x2003531, 0x2003631, 0x2003731, 0x2003831, 0x2003931, 0x2003032, 0x2003132, 0x2003232, 0x2003332, 0x2003432, 0x2003532, 0x2003632, 0x2003732, 0x2003832, 0x2003932, 0x2003033, 0x2003133, 0x2003233, 0x2003333, 0x2003433, 0x2003533, 0x2003633, 0x2003733, 0x2003833, 0x2003933, 0x2003034, 0x2003134, 0x2003234, 0x2003334, 0x2003434, 0x2003534, 0x2003634, 0x2003734, 0x2003834, 0x2003934, 0x2003035, 0x2003135, 0x2003235, 0x2003335, 0x2003435, 0x2003535, 0x2003635, 0x2003735, 0x2003835, 0x2003935, 0x2003036, 0x2003136, 0x2003236, 0x2003336, 0x2003436, 0x2003536, 0x2003636, 0x2003736, 0x2003836, 0x2003936, 0x2003037, 0x2003137, 0x2003237, 0x2003337, 0x2003437, 0x2003537, 0x2003637, 0x2003737, 0x2003837, 0x2003937, 0x2003038, 0x2003138, 0x2003238, 0x2003338, 0x2003438, 0x2003538, 0x2003638, 0x2003738, 0x2003838, 0x2003938, 0x2003039, 0x2003139, 0x2003239, 0x2003339, 0x2003439, 0x2003539, 0x2003639, 0x2003739, 0x2003839, 0x2003939};
static unsigned int digit100_rlz_sig2[100] = {0x0000030, 0x1000031, 0x1000032, 0x1000033, 0x1000034, 0x1000035, 0x1000036, 0x1000037, 0x1000038, 0x1000039, 0x2003031, 0x2003131, 0x2003231, 0x2003331, 0x2003431, 0x2003531, 0x2003631, 0x2003731, 0x2003831, 0x2003931, 0x2003032, 0x2003132, 0x2003232, 0x2003332, 0x2003432, 0x2003532, 0x2003632, 0x2003732, 0x2003832, 0x2003932, 0x2003033, 0x2003133, 0x2003233, 0x2003333, 0x2003433, 0x2003533, 0x2003633, 0x2003733, 0x2003833, 0x2003933, 0x2003034, 0x2003134, 0x2003234, 0x2003334, 0x2003434, 0x2003534, 0x2003634, 0x2003734, 0x2003834, 0x2003934, 0x2003035, 0x2003135, 0x2003235, 0x2003335, 0x2003435, 0x2003535, 0x2003635, 0x2003735, 0x2003835, 0x2003935, 0x2003036, 0x2003136, 0x2003236, 0x2003336, 0x2003436, 0x2003536, 0x2003636, 0x2003736, 0x2003836, 0x2003936, 0x2003037, 0x2003137, 0x2003237, 0x2003337, 0x2003437, 0x2003537, 0x2003637, 0x2003737, 0x2003837, 0x2003937, 0x2003038, 0x2003138, 0x2003238, 0x2003338, 0x2003438, 0x2003538, 0x2003638, 0x2003738, 0x2003838, 0x2003938, 0x2003039, 0x2003139, 0x2003239, 0x2003339, 0x2003439, 0x2003539, 0x2003639, 0x2003739, 0x2003839, 0x2003939};
//  lut generate by this code
// ======= start ========
// for (int i = 0; i < 1000; ++i)
// {
//     unsigned int lz = ((i < 100) + (i < 10));
//     unsigned int sig = 3 - lz;
//     unsigned int t = ((i / 100 + '0') << 0) +
//                      (((i % 100) / 10 + '0') << 8) +
//                      (((i % 100) % 10 + '0') << 16);
//     digit1000[i] = t;
//     digit1000_sig[i] = t + (3 << 24);
//     t >>= (lz * 8);// remove left zero
//     digit1000_rlz[i] = t + (lz << 24);
//     digit1000_rlz_sig[i] = t + (sig << 24);
//     if(i<100)digit100_rlz_sig[i] =digit100_rlz_sig2[i]= t + (sig << 24);
//     // printf("0x%x,", digit1000[i]);
//     // printf("0x%x,", digit1000_sig[i]);
//     // printf("0x%x,", digit1000_rlz[i]);
//     // printf("0x%x,", digit1000_rlz_sig[i]);
//     // if(i<100)printf("0x%x,", digit100_rlz_sig[i]);
// }
// digit100_rlz_sig2[0]=0x30;
// ======= end ========

static force_inline void byte_copy_4(void *dst, const void *src)
{
    memcpy(dst, src, 4);
}

static force_inline char *itoa_u64_xjb_impl_len_9(uint32_t val, char *buf)
{
    u64 aaa = ((u128)(val) * (18446744073710)) >> 64;
    *(u32 *)&buf[0] = digit1000_sig[aaa]; // 3
    u64 bbbccc = val - aaa * (1000 * 1000);
    u64 bbb = (bbbccc * (u64)4294968) >> 32;
    *(u32 *)&buf[3] = digit1000_sig[bbb]; // 3
    u64 ccc = bbbccc - bbb * 1000;
    *(u32 *)&buf[6] = digit1000_sig[ccc]; // 3
    return buf + 9;
}
char *itoa_u64_xjb(uint64_t val, char *buf)
{
    if (val < E6) // 1 -> 6 = aaa bbb = 3+3
    {
        // u64 aaa = ((u128)val * 18446744073709552) >> 64;/* (val / 1000) */
        u32 aaa = (val * (u64)1073742) >> 30;
        u32 bbb = val - aaa * 1000;
        u32 aaawr = ((aaa < 100u) ? digit100_rlz_sig2 : digit1000_sig)[aaa];
        u32 bbbwr = ((val < 100u) ? digit100_rlz_sig : digit1000_sig)[bbb];
        byte_copy_4(buf, &aaawr);                  // 0-3
        byte_copy_4(buf += (aaawr >> 24), &bbbwr); // 1-3
        return buf + (bbbwr >> 24);                // buf + sig
    }
    if (val < E6 * E6) // 7 -> 12 = aaa bbb ccc ddd
    {
        u32 aaabbb = (val * (u128)18446744073710) >> 64; // val / E6
        u32 cccddd = val - aaabbb * E6;
        u32 aaa = (aaabbb * (u64)4294968) >> 32;
        u32 bbb = aaabbb - aaa * 1000;
        u32 ccc = (cccddd * (u64)4294968) >> 32;
        u32 ddd = cccddd - ccc * 1000;
        u32 aaawr = ((aaa < 100) ? digit100_rlz_sig2 : digit1000_sig)[aaa];
        u32 bbbwr = ((aaabbb < 100) ? digit100_rlz_sig2 : digit1000_sig)[bbb];
        byte_copy_4(buf, &aaawr);                               // 0-3 digit
        byte_copy_4(buf += (aaawr >> 24), &bbbwr);              // 1-3 digit
        byte_copy_4(buf += (bbbwr >> 24), &digit1000_sig[ccc]); // 3
        byte_copy_4(buf += 3, &digit1000_sig[ddd]);             // 3
        return buf + 3;
    }
    if (val < E6 * E6 * E6) // 13 -> 18 = aaa bbb ccc ddd eee ffff
    {
        u64 aaabbb = val / (E6 * E6);
        u64 cccdddeeefff = val - aaabbb * (E6 * E6);
        u64 cccddd = ((u128)cccdddeeefff * 18446744073710) >> 64;
        u64 eeefff = cccdddeeefff - cccddd * E6;

        u32 aaa = (aaabbb * (u64)4294968) >> 32;
        u32 bbb = aaabbb - aaa * 1000;
        u32 ccc = (cccddd * (u64)4294968) >> 32;
        u32 ddd = cccddd - ccc * 1000;
        u32 eee = (eeefff * (u64)4294968) >> 32;
        u32 fff = eeefff - eee * 1000;

        u32 aaawr = ((aaa < 100) ? digit100_rlz_sig2 : digit1000_sig)[aaa];
        u32 bbbwr = ((aaabbb < 100) ? digit100_rlz_sig2 : digit1000_sig)[bbb];
        byte_copy_4(buf, &aaawr);
        byte_copy_4(buf += (aaawr >> 24), &bbbwr);
        byte_copy_4(buf += (bbbwr >> 24), &digit1000_sig[ccc]);
        byte_copy_4(buf += 3, &digit1000_sig[ddd]);
        byte_copy_4(buf += 3, &digit1000_sig[eee]);
        byte_copy_4(buf += 3, &digit1000_sig[fff]);
        return buf + 3;
    }
    {
        // 19 -> 20 digit = 2+9+9
        const u64 E9 = 1000 * 1000 * 1000;
        u64 tmp = val / E9;
        u64 low = (val - tmp * E9); // 9 digit
        u64 hgh = (tmp / E9);       // 1-2 digit
        u64 mid = (tmp - hgh * E9); // 9 digit

        // u64 : 19-20 digit
        u32 hgh_write = digit100_rlz_sig2[hgh];
        byte_copy_4(buf, &hgh_write); // 1-2 digit
        buf += (hgh_write >> 24);     // 1 or 2
        // i64 : 19 digit
        // *buf++ = hgh+'0';

        buf = itoa_u64_xjb_impl_len_9(mid, buf);
        buf = itoa_u64_xjb_impl_len_9(low, buf);
        return buf;
    }
}
char *itoa_u32_xjb(uint32_t val, char *buf)
{
    if (val < 1000)
    {
        u32 aaawr = ((val < 100) ? digit100_rlz_sig2 : digit1000_sig)[val];
        byte_copy_4(buf, &aaawr); // 1-3
        return buf += (aaawr >> 24);
    }
    if (val < E6)
    {
        u32 aaa = (val * (u64)1073742) >> 30;
        u32 bbb = val - aaa * 1000;
        u32 aaawr = ((aaa < 100) ? digit100_rlz_sig2 : digit1000_sig)[aaa];
        u32 bbbwr = digit1000_sig[bbb];
        byte_copy_4(buf, &aaawr);                  // 0-3
        byte_copy_4(buf += (aaawr >> 24), &bbbwr); // 1-3
        return buf + 3;
    }
    // if (val < E6) // 1->6 = aaa bbb = 3+3
    // {
    //     //u32 aaa = ((u128)val * 18446744073709552) >> 64;/* (val / 1000) */
    //     u32 aaa = (val * (u64)1073742) >> 30;
    //     u32 bbb = val - aaa * 1000;
    //     u32 aaawr = ((aaa < 100) ? digit100_rlz_sig2 : digit1000_sig)[aaa];
    //     u32 bbbwr = ((val < 100) ? digit100_rlz_sig : digit1000_sig)[bbb];
    //     byte_copy_4(buf, &aaawr);//0-3
    //     byte_copy_4(buf += (aaawr >> 24), &bbbwr);//1-3
    //     return buf + (bbbwr >> 24);
    // }
    if (val < E6 * 1000) // 7-9
    {
        // u64 lz = val < (10*1000*1000);//1e7
        uint32_t aaa = (val * (u64)1125899907) >> 50; // val/E6 ; 2**50>1e14
        // byte_copy_2(buf + 0, digit100 + aa * 2 + lz);
        u32 aaawr = ((aaa < 100) ? digit100_rlz_sig2 : digit1000_sig)[aaa];
        // byte_copy_4(buf, &aaawr);
        buf += (aaawr >> 24);
        // buf -= lz;
        uint32_t bbbccc = val - aaa * (1000 * 1000);
        uint32_t bbb = (bbbccc * (u64)4294968) >> 32;
        uint32_t ccc = bbbccc - bbb * 1000;
        u64 bbbw = digit1000_sig[bbb];
        u64 cccw = digit1000_sig[ccc];
        byte_copy_4(buf + 0, &bbbw);
        byte_copy_4(buf + 3, &cccw);
        return buf + 6;
    }
    { // 7 -> 10 = a bbb ccc ddd = 1+3 + 3+3 = 4+6
        u32 abbb = ((u128)val * 18446744073710) >> 64;
        u32 cccddd = val - abbb * 1000000;
        u32 a = (abbb * 16778) >> 24; // abbb/1000 ; 2**24>1e7
        u32 bbb = abbb - a * 1000;
        u32 ccc = (cccddd * (u64)1073742) >> 30; // cccddd/1000   2**30>1e9
        u32 ddd = cccddd - ccc * 1000;
        u32 bbbwr = ((abbb < 100) ? digit100_rlz_sig : digit1000_sig)[bbb];
        *buf = a + '0';                                         // 0-1
        byte_copy_4(buf += (a > 0), &bbbwr);                    // 1-3
        byte_copy_4(buf += (bbbwr >> 24), &digit1000_sig[ccc]); // 3
        byte_copy_4(buf += 3, &digit1000_sig[ddd]);             // 3
        return buf + 3;
    }
}

char *itoa_i32_xjb(int32_t val, char *buf)
{
    uint32_t pos = *(uint32_t *)&val;
    uint32_t neg = ~pos + 1;
    size_t sign = val < 0;
    *buf = '-';
    return itoa_u32_xjb(sign ? neg : pos, buf + sign);
}
char *itoa_i64_xjb(int64_t val, char *buf)
{
    uint64_t pos = *(uint64_t *)&val;
    uint64_t neg = ~pos + 1;
    size_t sign = val < 0;
    *buf = '-';
    return itoa_u64_xjb(sign ? neg : pos, buf + sign);
}

/* benckmark config */
int itoa_xjb_available_32 = 1;
int itoa_xjb_available_64 = 1;

#endif