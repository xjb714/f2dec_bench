
中文版论文(Chinese version of the paper)：print_acc_by_xjb.docx or print_acc_by_xjb.pdf


此文章属于草稿，完稿后可能与现在版本有较大差异。
This article is a draft. After completion, it may differ significantly from the current version.


算法名和对应的代码实现
The algorithm name and the corresponding code implementation

itoa : itoa_xjb.c

d2sci : double/d2sci/d2sci.cpp
f2sci : float/f2sci.cpp

schubfach32 : float/schubafch_32.cpp -> ToDecimal32()
schubfach64 : double/schubafch_64.cpp -> ToDecimal64()

schubafch_xjb32 : float/schubafch_32.cpp -> ToDecimal32_xjb()
schubafch_xjb64 : float/schubafch_64.cpp -> ToDecimal64_xjb()

xjb32 : float/schubafch_32.cpp -> ToDecimal32_xjb_v7_v3()   or float/xjb32.cpp
xjb64 : double/schubafch_64.cpp -> ToDecimal64_xjb_v2()      or double/xjb64.cpp


author : 向俊波  1302035400@qq.com 
date : 2025.9.3

代码中包含大量无关注释，最终版请删除。
xjb64算法还在持续优化中，最终代码实现可能与现在版本有差异。