#include <iostream>
#include <chrono>
#include <random>
#include <vector>

#include "schubfach_32.cpp"

std::random_device rd;
std::mt19937_64 gen(rd());
const int N = 1<<27;//
unsigned int * data;

unsigned long long get_cycle()
{
    uint64_t low, high;
    __asm volatile("rdtsc" : "=a"(low), "=d"(high));
    return (high << 32) | low;
}
unsigned long long getns()
{
    auto now = std::chrono::high_resolution_clock::now();
    auto nanos = std::chrono::duration_cast<std::chrono::nanoseconds>(now.time_since_epoch()).count();
    return nanos;
}
void init(){
    printf("init start , very slow , please wait one minute : \n");
    auto t1 = getns();
    std::random_device rd;
    std::mt19937 gen32(rd());
    unsigned int M = (0xff << 23) - 1; // 2139095039
    std::uniform_int_distribution<uint32_t> dist(1, M);// [1,M]
    data = (unsigned int *)malloc( M * sizeof(unsigned int));
    for (uint32_t i = 0; i < M; ++i) {
        //data[i-1] = i;
        data[i] = dist(gen32);
    }
    //very slow
    // for (uint64_t i = M - 1; i > 0; --i) {
    //     std::uniform_int_distribution<uint64_t> dist(0, i);
    //     uint64_t j = dist(gen);
    //     std::swap(data[i], data[j]);
    // }
    // std::cout << "前10个元素: ";
    // for (int i = 0; i < 10 && i < M; ++i) {
    //     std::cout << data[i] << " ";
    // }
    // std::cout << std::endl;
    auto t2 = getns();
    printf("init finish , cost %lf s\n",(t2 - t1) * 1e-9);
}
void check_all_float()
{
    printf("checking,please wait one minute; if ok : print all equal\n");
    int is_ok = 1;
    for (unsigned i = 1; i < (0xff << 23); ++i) // 0xff<<23 == 2139095040
    {
        unsigned u = i;
        unsigned sig = u & ((1 << 23) - 1);
        unsigned exp = u >> 23;

        const auto dec = ToDecimal32_xjb(sig, exp);// ToDecimal32 is slow
        unsigned digit = dec.digits;
        int e10 = dec.exponent;

        const auto dec_xjb = ToDecimal32_xjb_v7_v3(sig, exp);
        unsigned digit_xjb = dec_xjb.digits;
        int e10_xjb = dec_xjb.exponent;

        if (!(digit == digit_xjb && e10 == e10_xjb))
        {
            is_ok = 0;
            printf("sig=%u,exp=%u,d=%u,d_x=%u,e10=%d,e10_x=%d\n", sig, exp, digit, digit_xjb, e10, e10_xjb);
            // exit(0);
        }
    }
    if (is_ok)
        printf("all equal\n");
    else
        printf("not all equal\n");
}
void check_all_subnormal_float()
{
    printf("checking,please wait one minute; if ok : print all equal\n");
    int is_ok = 1;
    for (unsigned i = 1; i < (0x1 << 23); ++i) // 0xff<<23 == 2139095040
    //for (unsigned i = 1; i < 1000; ++i)
    {
        unsigned u = i;
        unsigned sig = u & ((1 << 23) - 1);
        unsigned exp = u >> 23;

        const auto dec = ToDecimal32_xjb_v7(sig, exp);
        unsigned digit = dec.digits;
        int e10 = dec.exponent;

        const auto dec_xjb = ToDecimal32_xjb_v7_v3(sig, exp);
        unsigned digit_xjb = dec_xjb.digits;
        int e10_xjb = dec_xjb.exponent;

        if (!(digit == digit_xjb && e10 == e10_xjb))
        {
            is_ok = 0;
            printf("sig=%u,exp=%u,d=%u,d_x=%u,e10=%d,e10_x=%d\n", sig, exp, digit, digit_xjb, e10, e10_xjb);
            // exit(0);
        }
    }
    if (is_ok)
        printf("all equal\n");
    else
        printf("not all equal\n");
}
void check_all_irregular_float()
{
    printf("checking all irregular ,please wait one minute; if ok : print all equal\n");
    int is_ok = 1;
    for (unsigned i = 1; i < 255; ++i) // 0xff<<23 == 2139095040
    //for (unsigned i = 1; i < 1000; ++i)
    {
        unsigned sig = 0;
        unsigned exp = i;

        const auto dec = ToDecimal32_xjb_v7(sig, exp);
        unsigned digit = dec.digits;
        int e10 = dec.exponent;

        const auto dec_xjb = ToDecimal32_xjb_v7_v3(sig, exp);
        unsigned digit_xjb = dec_xjb.digits;
        int e10_xjb = dec_xjb.exponent;

        if (!(digit == digit_xjb && e10 == e10_xjb))
        {
            is_ok = 0;
            if(digit_xjb*10!=digit)
                printf("sig=%u,exp=%u,d=%u,d_x=%u,e10=%d,e10_x=%d\n", sig, exp, digit, digit_xjb, e10, e10_xjb);
            // exit(0);
        }
    }
    if (is_ok)
        printf("all irregular equal\n");
    else
        printf("not all irregular equal\n");
}
void check_one()
{
    // unsigned sig = 0;
    // unsigned exp = 31;

    //14855922*2**-80;
    unsigned sig = 6467314;
    unsigned exp = 70;

    const auto dec = ToDecimal32_xjb_v7(sig, exp);
    unsigned digit = dec.digits;
    int e10 = dec.exponent;

    const auto dec_xjb = ToDecimal32_xjb_v7_v3(sig, exp);
    unsigned digit_xjb = dec_xjb.digits;
    int e10_xjb = dec_xjb.exponent;

    // const auto dec_xjb = ToDecimal32_xjb_v7(sig, exp);
    // unsigned digit_xjb = dec_xjb.digits;
    // int e10_xjb = dec_xjb.exponent;

    printf("digit = %u, e10 = %d, digit_xjb = %u, e10_xjb = %d\n",digit,e10, digit_xjb, e10_xjb);
}
void check_input()
{
    while (1)
    {
        printf("input a postive float number:");
        float v;
        std::cin >> v;
        unsigned u = *(unsigned *)&v;
        unsigned sig = u & ((1 << 23) - 1);
        unsigned exp = u >> 23;
        const auto dec_xjb = ToDecimal32_xjb_v6(sig, exp);
        unsigned digit_xjb = dec_xjb.digits;
        int e10_xjb = dec_xjb.exponent;
        printf("digit_xjb = %u,e10_xjb = %d\n", digit_xjb, e10_xjb);
    }
}
void bench_all_float_seq()
{
    auto t1 = getns();
    auto c1 = get_cycle();
    unsigned long long sum = 0;
    unsigned int N = 10000 * 10000 ;
    //unsigned int N =  (0xff << 23) - 1;//2139095039
    for (unsigned i = 1; i <= N; ++i)
    {
        unsigned u = i;
        unsigned sig = u & ((1 << 23) - 1);
        unsigned exp = u >> 23;
        const auto dec = ToDecimal32_xjb_v7_v3(sig, exp);
        unsigned digit = dec.digits;
        //int e10 = dec.exponent;
        sum += digit;
    }
    auto t2 = getns();
    auto c2 = get_cycle();
    printf("seq : every num %lf ns,%lf cycle ,sum = %llu\n", (t2 - t1) * (1.0 / N), (c2 - c1) * (1.0 / N), sum);
}
void bench_all_float_rnd()
{
    auto t1 = getns();
    auto c1 = get_cycle();
    unsigned long long sum = 0;
    unsigned int N =  (0xff << 23) - 1;//2139095039
    for (unsigned i = 0; i < N; ++i)
    {
        unsigned u = data[i];
        unsigned sig = u & ((1 << 23) - 1);
        unsigned exp = u >> 23;
        const auto dec = ToDecimal32_xjb_v7_v3(sig, exp);
        unsigned digit = dec.digits;
        int e10 = dec.exponent;
        sum += digit;//
    }
    auto t2 = getns();
    auto c2 = get_cycle();
    printf("rnd : every num %lf ns,%lf cycle ,sum = %llu\n", (t2 - t1) * (1.0 / N), (c2 - c1) * (1.0 / N), sum);
}
int main()
{
    //check_all_irregular_float();

    //check_all_float();

    //check_all_subnormal_float();

    //check_one();

    //check_input();

    bench_all_float_seq();
    
    //bench random float numbers

    if(0)
    {
        init();

        bench_all_float_rnd();

        //free();
    }

    printf("main exit\n");
}