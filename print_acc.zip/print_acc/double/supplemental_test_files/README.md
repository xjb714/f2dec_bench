# supplemental_test_files
Supplemental data files for testing floating parsing (credit: Nigel Tao for the data)


LICENSE file (Apache 2): https://github.com/nigeltao/parse-number-fxx-test-data/blob/main/LICENSE
