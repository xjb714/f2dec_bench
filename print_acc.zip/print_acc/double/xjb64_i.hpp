#include "xjb64.cpp"

static inline void xjb_f64_to_dec(double v,unsigned long long* dec,int *e10)
{
    unsigned long long vi = *(unsigned  long long*)&v;
    unsigned long long sig = vi & ((1ull<<52) - 1);
    unsigned long long exp = (vi>>52) & 2047;

    // unsigned long sig_bin,exp_bin;
    // if( exp ) [[likely]]
    // {
    //     sig_bin = sig | (1ull<<52);
    //     exp_bin = exp - 1075;//max is 2046-1075=971
    // } 
    // else
    // {
    //     sig_bin = sig;
    //     exp_bin = -1074;//min is 1-1075=-1074 
    // }
    //exp_bin : [-1074,971]
    xjb64(sig,exp,(uint64_t*)dec,e10) ;

    //*dec = r.digits;
    //*e10 = r.exponent;
}