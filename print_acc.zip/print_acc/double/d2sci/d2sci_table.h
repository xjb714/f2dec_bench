extern const unsigned long long powers_ten_reverse[687] ;

extern const double _10en[324 * 2 + 1] ;

extern const unsigned int digit_000_999[1000] ;

extern const unsigned int digit_00_99[100] ;

extern const unsigned long long exp_result3[324 + 308 + 1] ;

extern const unsigned long long seq_exp_result3[324 + 308 + 1] ;

extern const unsigned int digit1000e[1000] ;

extern const unsigned int digit1000[1000];

extern const unsigned short digit100[100];